#pragma once

#include <iostream>
#include "opencv2/opencv.hpp"
#include "opencv2/core/base.hpp"
#include <iostream>
#include <algorithm>


using namespace std;

cv::Mat atif_mef(const cv::Mat I_hazy, float clip_range = 4.0);

std::vector<cv::Mat> gamma_correction(const cv::Mat src, const float* gamma);
void clahe(const cv::Mat src, cv::Mat &dst, float clip_range);

// box filter
cv::Mat cumSum(cv::Mat in); 
cv::Mat cumSumHorz(cv::Mat in);
cv::Mat boxfilter(cv::Mat imSrc, int r);
void printMat(cv::Mat mat, string str);

// fastGF
cv::Mat fastGF(cv::Mat I, int r, double eps, double s);

cv::Mat conv2(cv::Mat a, cv::Mat filt); 
cv::Mat padImage(cv::Mat Img, int y, int x);
cv::Mat rgb2gray(cv::Mat rgb); 
cv::Mat imresize(cv::Mat Img);

cv::Mat fastExpoFuse(std::vector<cv::Mat> Io, int r);
cv::Mat coordinator(cv::Mat FI, cv::Mat I_hazy);

cv::Mat atif_mef_thermal(const cv::Mat I, float clip_range);
cv::Mat fastExpoFuse_thermal(std::vector<cv::Mat> Io, int r);

