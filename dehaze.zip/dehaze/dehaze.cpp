
#include "helper.h"
#include "EdgeEnhancement.h"
#include "AutoWhiteBalance.h"

#include "opencv2/imgproc.hpp"
#include <vector>
#include <string>
#include <filesystem>
#include <fstream>

void readPrnuTable(char *fileName, float *gain, int32_t *offset) {
	// PRNU table reading
	FILE * pFile;
	long lSize;
	uint32_t * buffer_int;
	size_t result;

	fopen_s(&pFile, fileName, "rb");
	if (pFile == NULL) { fputs("File error", stderr); exit(1); }
	// obtain file size:
	fseek(pFile, 0, SEEK_END);
	lSize = ftell(pFile);
	rewind(pFile);

	buffer_int = (uint32_t*)malloc(sizeof(char)*lSize);
	if (buffer_int == NULL) { fputs("Memory error", stderr); exit(2); }
	result = fread(buffer_int, 4, lSize / 4, pFile);
	if (result != lSize / 4) { fputs("Reading error", stderr); exit(3); }

	//gain calculation
	// gain = (float*)malloc(sizeof(char)* lSize);
	for (size_t i = 0; i < lSize / 4; i++)
		gain[i] = (buffer_int[i] & 65535) / pow(2, 14);

	// offset = (int32_t*)malloc(sizeof(char)* lSize);
	for (size_t i = 0; i < lSize / 4; i++) {
		int32_t temp = buffer_int[i] / pow(2, 16);
		int s = temp / pow(2, 15);
		if (s >= 1) offset[i] = temp - pow(2, 16);
		else offset[i] = temp;
	}

	fclose(pFile);
	free(buffer_int);
}

void getPrnuTable(char *fileName, int x_shift, int y_shift, cv::Mat &_gain, cv::Mat &_offset) {
	float *gain = (float*)malloc(sizeof(int) * 2048 * 2048);
	int32_t *offset = (int32_t*)malloc(sizeof(int) * 2048 * 2048);
	readPrnuTable(fileName, gain, offset);

	_gain = cv::Mat(cv::Size(2048, 2048), CV_32F, gain);
	_offset = cv::Mat(cv::Size(2048, 2048), CV_32S, offset);

	int x_range = (2048 - 1080) / 2 + y_shift;
	int y_range = (2048 - 1920) / 2 + x_shift;
	_gain = _gain(cv::Range(x_range - 1, x_range + 1079), cv::Range(y_range - 1, y_range + 1919));
	_offset = _offset(cv::Range(x_range - 1, x_range + 1079), cv::Range(y_range - 1, y_range + 1919));

	x_range = (1080 - 1024) / 2;
	y_range = (1920 - 1280) / 2;
	_gain = _gain(cv::Range(x_range - 1, x_range + 1023), cv::Range(y_range - 1, y_range + 1279));
	_offset = _offset(cv::Range(x_range - 1, x_range + 1023), cv::Range(y_range - 1, y_range + 1279));
}

void dehazeFrame() {

	string framePath = "//mgeods/Statik2/GIBGTM/Personal_Backups/ZK_backup/180822_day_thermal/dayFrames_2022-06-03_03-51-47.585_part2/2022-06-03_07-32-17.831_frame_250.tif";
	cv::Mat hazy_image = cv::imread(framePath, -1);
	auto fov = hazy_image.at<short>(1025, 68);
	hazy_image = hazy_image(cv::Range(0, 1024), cv::Range(0, 1280));

	char *prnuTableName = "";
	int x_shift, y_shift;
	cv::Mat gain, offset;
	bool applyPrnu = false;

	if (fov == 4) {
		prnuTableName = "DAY_PRNUN.prnu";
		x_shift = 32;
		y_shift = -222;
		applyPrnu = true;
	}
	if (fov == 5) {
		prnuTableName = "DAY_PRNUVN.prnu";
		x_shift = 58;
		y_shift = -250;
		applyPrnu = true;
	}

	hazy_image.convertTo(hazy_image, CV_32F);
	if (applyPrnu) {
		getPrnuTable(prnuTableName, x_shift, y_shift, gain, offset);
		cv::multiply(hazy_image, gain, hazy_image);
		hazy_image += offset;
	}

	hazy_image.convertTo(hazy_image, CV_16U);
	if (fov <= 3) cv::demosaicing(hazy_image, hazy_image, cv::COLOR_BayerRG2BGR);
	else cv::demosaicing(hazy_image, hazy_image, cv::COLOR_BayerGR2BGR);

	cv::Mat res = AWB_MeanLuminance(hazy_image); //res 16 bit
	cv::Mat dehazed = atif_mef(res, 4);
	cv::Mat c = dehazed.clone();

	enhanceEdges(res, dehazed);

	dehazed.convertTo(dehazed, CV_8U, (1 / pow(2, 8)));
	cv::imshow("res", dehazed);
	cv::waitKey();

	cv::Mat diff = abs(c - dehazed);
	cv::imshow("diff", diff * 40 );
	cv::waitKey();

	cv::imwrite("3.tif", diff*40);

}

int main(int argc, char *argv[])
{
	dehazeFrame();
	return 0;
}


