
#include "helper.h"


using namespace std;

cv::Mat atif_mef(const cv::Mat I, float clip_range) {

	// 10 bit input
	cv::Mat I_hazy;
	//I.convertTo(I_hazy, CV_32FC3, (1.0 / 1023.0));
	I.convertTo(I_hazy, CV_32FC3, (1.0 / 65535.0));
	vector<cv::Mat> Images;

	//gamma correction
	float gamma[] = {1.2, 2, 4, 8}; 
	std::vector<cv::Mat> gammaCorrectedImgs = gamma_correction(I_hazy, gamma);
	Images.insert(Images.end(), gammaCorrectedImgs.begin(), gammaCorrectedImgs.end());

	//clahe
	cv::Mat claheIn, claheOut;
	I_hazy.convertTo(claheIn, CV_8UC3, 255.0);
	clahe(claheIn, claheOut, clip_range);
	claheOut.convertTo(claheOut, CV_32FC3, (1.0 / 255.0));
	Images.push_back(claheOut);

	int r = 12;
	cv::Mat R = fastExpoFuse(Images, r);
	return coordinator(R, I_hazy);
}

std::vector<cv::Mat> gamma_correction(const cv::Mat src, const float* gamma) {

	std::vector<cv::Mat> f;
	for (int i = 0; i < 4 ; i++)
	{
		cv::Mat res;
		cv::pow(src, gamma[i], res);
		f.push_back(res);
	}
	return f;
}

void clahe(const cv::Mat src, cv::Mat &dst, float clip_range) {

	cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE();
	clahe->setClipLimit(clip_range); //4
	
	std::vector<cv::Mat> bgr;
	cv::split(src, bgr);
	clahe->apply(bgr[0], bgr[0]);
	clahe->apply(bgr[1], bgr[1]);
	clahe->apply(bgr[2], bgr[2]);
	cv::merge(bgr, dst);
}

// box filter
cv::Mat cumSum(cv::Mat in) {

	cv::Mat cumsum = cv::Mat::zeros(cv::Size(in.cols, in.rows), CV_32F);

	//memcpy(&cumsum, &in, in.cols * sizeof(float));
	for (int i = 0; i < in.cols; i++)
	 	cumsum.at<float>(0, i) = in.at<float>(0, i);

	for (int i = 0; i < in.rows - 1; i++)
	{
		for (int j = 0; j < in.cols; j++) {
			cumsum.at<float>(i + 1, j) = in.at<float>(i + 1, j) + cumsum.at<float>(i, j);
		}
	}

	return cumsum;
}

cv::Mat cumSumHorz(cv::Mat in) {

	cv::Mat cumsum = cv::Mat::zeros(cv::Size(in.cols, in.rows), CV_32F);

	for (int i = 0; i < in.rows; i++)
		cumsum.at<float>(i, 0) = in.at<float>(i, 0);

	for (int i = 0; i < in.cols - 1; i++){
		for (int j = 0; j < in.rows; j++) {
			cumsum.at<float>(j, i + 1) = in.at<float>(j, i + 1) + cumsum.at<float>(j, i);
		}
	}

	return cumsum;
}

cv::Mat boxfilter(cv::Mat imSrc, int r) {

	cv::Mat imCum = cumSum(imSrc);
	cv::Mat imDst = cv::Mat::zeros(cv::Size(imCum.cols, imCum.rows), imCum.type());
	int h = imCum.rows;

	// part 1 
	float* ref = (float*)&imCum.data[0];

	memcpy(&imDst.data[0], &ref[r * imCum.cols], sizeof(float) * (r + 1) * imCum.cols);
	//	for (int i = 0; i < r + 1; i++)
	//	{
	//		for (int j = 0; j < imCum.cols; j++)
	//		{
	//			imDst.at<float>(i, j) = imCum.at<float>(i + r, j);
	//		}
	//	}

	for (int i = 0; i < h - 2 * r - 1; i++)
	{
		for (int j = 0; j < imCum.cols; j++)
		{
			imDst.at<float>(r + 1 + i, j) = imCum.at<float>(2 * r + 1 + i, j) - imCum.at<float>(i, j);
		}
	}

	cv::Mat lastRow_imCum = cv::Mat::ones(cv::Size(imCum.cols, 1), CV_32F);

	for (int i = 0; i < imCum.cols; i++)
	{
		lastRow_imCum.at<float>(0, i) = imCum.at<float>(imCum.rows - 1, i);
	}

	cv::Mat repmat_inSum = cv::repeat(lastRow_imCum, r, 1);

	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < imCum.cols; j++)
		{
			imDst.at<float>(h - r + i, j) = repmat_inSum.at<float>(i, j) - imCum.at<float>(h - 2 * r - 1 + i, j);
		}
	}

	// part 2 
	int w = imCum.cols;
	imCum = cumSumHorz(imDst);

	for (int i = 0; i < r + 1; i++)
	{
		for (int j = 0; j < imCum.rows; j++)
		{
			imDst.at<float>(j, i) = imCum.at<float>(j, r + i);
		}
	}

	for (int i = 0; i < w - 2 * r - 1; i++)
	{
		for (int j = 0; j < imCum.rows; j++)
		{
			imDst.at<float>(j, i + r + 1) = imCum.at<float>(j, i + 2 * r + 1) - imCum.at<float>(j, i);
		}
	}

	cv::Mat lastCol_imCum = cv::Mat::ones(cv::Size(1, imCum.rows), CV_32F);

	for (int i = 0; i < imCum.rows; i++)
	{
		lastCol_imCum.at<float>(i, 0) = imCum.at<float>(i, imCum.cols - 1);
	}

	cv::Mat repmat2_imCum = cv::repeat(lastCol_imCum, 1, r);

	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < imCum.rows; j++)
		{
			imDst.at<float>(j, w - r + i) = repmat2_imCum.at<float>(j, i) - imCum.at<float>(j, w - 2 * r - 1 + i);
		}
	}

	return imDst;
}

void printMat(cv::Mat mat, string str) {

	cout << str << endl;
	for (int i = 0; i < mat.rows; i++)
	{
		for (int j = 0; j < mat.cols; j++)
		{
			cout << mat.at<float>(i, j) << "\t";
		}
		cout << endl;
	}
	cout << endl;
}

// fastGF
cv::Mat fastGF(cv::Mat I, int r, double eps, double s) {

	// I is a grayscale image, and between 0-1
	cv::Mat I_sub;
	cv::resize(I, I_sub, cv::Size(round(I.cols * (1 / s))/2, round(I.rows * (1 / s))/2), cv::INTER_NEAREST);

	auto r_sub = std::max(1.0, round(r / s));
	int hei = I_sub.rows;
	int wid = I_sub.cols;

	cv::Mat onesheiwei = cv::Mat::ones(hei, wid, CV_32F);
	cv::Mat N = boxfilter(onesheiwei, r_sub);
	//cv::Mat N;
	//int t = r_sub;
	//cv::boxFilter(onesheiwei, N, -1, cv::Size(5,5));

	cv::Mat mean_I = boxfilter(I_sub, r_sub);
	cv::divide(mean_I, N, mean_I);

	cv::multiply(I_sub, I_sub, I_sub);
	cv::Mat mean_II = boxfilter(I_sub, r_sub);
	cv::divide(mean_II, N, mean_II);

	cv::Mat mean_I_2;
	cv::multiply(mean_I, mean_I, mean_I_2);
	cv::Mat cov_Ip = mean_II - mean_I_2;

	cv::Mat a, b;
	cv::Mat m = (cov_Ip + eps);
	cv::divide(cov_Ip, m, a);

	cv::Mat temp;
	cv::multiply(a, mean_I, temp);
	b = mean_I - temp;

	cv::Mat mean_a = boxfilter(a, r_sub);
	cv::divide(mean_a, N, mean_a);
	cv::Mat mean_b = boxfilter(b, r_sub);
	cv::divide(mean_b, N, mean_b);

	cv::Mat mean_a_res, mean_b_res;
	cv::resize(mean_a, mean_a_res, cv::Size(I.cols, I.rows), cv::INTER_LINEAR);
	cv::resize(mean_b, mean_b_res, cv::Size(I.cols, I.rows), cv::INTER_LINEAR);

	cv::Mat comp1;
	cv::multiply(mean_a_res, I, comp1);
	cv::Mat q = comp1 + mean_b_res;

	return q;
}

cv::Mat conv2(cv::Mat a, cv::Mat filt) {
	cv::Mat result;
	cv::filter2D(a, result, -1, filt);
	return result(cv::Range(3, result.rows - 3), cv::Range(3, result.cols - 3));
}

cv::Mat padImage(cv::Mat Img, int y, int x) {
	// padding always symmetrical and both directions
	cv::Mat result;
	cv::copyMakeBorder(Img, result, y, y, x, x, cv::BORDER_REFLECT);
	return result;
}

cv::Mat rgb2gray(cv::Mat rgb) {

	if (rgb.type() != 16) 
		rgb.convertTo(rgb, CV_8UC3, 255);

	cv::Mat gray;
	cv::cvtColor(rgb, gray, cv::COLOR_BGR2GRAY); 
	gray.convertTo(gray, CV_32F);
	gray = gray / 255.0;

	return gray;
}

cv::Mat imresize(cv::Mat Img, float s) {
	s = 1 / s; 
	cv::Mat result;
	cv::resize(Img, result, cv::Size(std::round(Img.cols * s), std::round(Img.rows * s)), 0,0,0);
	return result;
}

cv::Mat fastExpoFuse(std::vector<cv::Mat> Io, int r) {
	
	// [Hei, Wid, ~, N] = size(Io);
	int Hei = Io[0].rows;
	int Wid = Io[0].cols;
	int N = Io.size();

	//  < Parameters > 
	float alpha = 1.1;
	float gSig = 0.2;
	float lSig = 0.5;
	float SigD = 0.12;

	float epsil = 0.25; 
	int np = Hei*Wid;

	cv::Mat H = cv::Mat::ones(cv::Size(7, 7), CV_32F);
	H = H / (49);

	// cv::Mat L1 = cv::Mat::ones(cv::Size(Wid, Hei), CV_32FC(6)); // ?? daha h�zl� m� olur ? 

	std::vector<cv::Mat> L;
	std::vector<cv::Mat> gMu;
	std::vector<cv::Mat> lMu;
	cv::Mat Iones = cv::Mat::ones(cv::Size(Wid, Hei), CV_32F);

	for (int i = 0; i < N; i++)
	{
		cv::Mat Ig = rgb2gray(Io[i]);
		cv::Mat IgPad = padImage(Ig, 3, 3);
		cv::Mat tempL = conv2(IgPad, H);
		L.push_back(tempL);

		double coeff = cv::sum(Ig)[0] / np;
		gMu.push_back(Iones * coeff);

		cv::Mat temp_lMu = fastGF(Ig, r, epsil, 2.5);
		lMu.push_back(temp_lMu);
	}

	float Sig2 = 2 * pow(SigD, 2);
	std::vector<cv::Mat> sMap;
	std::vector<cv::Mat> muMap;

	cv::Mat normalizerS = cv::Mat::zeros(cv::Size(Wid, Hei), CV_32FC1);
	cv::Mat normalizerMu = cv::Mat::zeros(cv::Size(Wid, Hei), CV_32FC1);

	for (int i = 0; i < N; i++)
	{
		sMap.push_back(cv::Mat::ones(cv::Size(Wid, Hei), CV_32FC1));
		cv::Mat t = (L[i] - 0.5);
		cv::pow(t, 2.0, t);
		t = t / Sig2;
		t = t *(-1);
		cv::exp(t, sMap[i]);
		sMap[i] = sMap[i] + 1e-6;
		cv::add(normalizerS, sMap[i], normalizerS);

		muMap.push_back(cv::Mat::ones(cv::Size(Wid, Hei), CV_32FC1));
		cv::Mat t2 = (gMu[i] - 0.5);
		cv::pow(t2, 2.0, t2);
		t2 = t2 / (pow(gSig, 2));
		cv::Mat t3 = (lMu[i] - 0.5);
		cv::pow(t3, 2.0, t3);
		t3 = t3 / (pow(lSig, 2));

		cv::add(t3, t2, t2);
		t2 = t2 * (-0.5);
		cv::exp(t2, muMap[i]);

		cv::add(normalizerMu, muMap[i], normalizerMu);
	}

	for (int h = 0; h < sMap.size(); h++) {
		cv::divide(sMap[h], normalizerS, sMap[h]);
		cv::divide(muMap[h], normalizerMu, muMap[h]);
	}


	std::vector<cv::Mat> Ist_b, Ist_g, Ist_r, channels;

	for (int n = 0; n < lMu.size(); n++)
	{
		cv::split(Io[n], channels);
		cv::Mat y;

		cv::subtract(channels[0], lMu[n], y);
		Ist_b.push_back(y.clone());

		cv::subtract(channels[1], lMu[n], y);
		Ist_g.push_back(y.clone());

		cv::subtract(channels[2], lMu[n], y);
		Ist_r.push_back(y.clone());

		channels.clear();
	}

	cv::Mat firstChannel = cv::Mat::zeros(cv::Size(Wid, Hei), CV_32F);
	cv::Mat secondChannel = cv::Mat::zeros(cv::Size(Wid, Hei), CV_32F);
	cv::Mat thirdChannel = cv::Mat::zeros(cv::Size(Wid, Hei), CV_32F);

	for (int n = 0; n < lMu.size(); n++)
	{
		cv::Mat a, b, c;
		cv::multiply(muMap[n], lMu[n], b);

		cv::multiply(sMap[n], Ist_b[n], a, alpha);
		cv::add(a, b, c);
		cv::add(firstChannel, c.clone(), firstChannel);

		cv::multiply(sMap[n], Ist_g[n], a, alpha);
		cv::add(a, b, c);
		cv::add(secondChannel, c.clone(), secondChannel);

		cv::multiply(sMap[n], Ist_r[n], a, alpha);
		cv::add(a, b, c);
		cv::add(thirdChannel, c.clone(), thirdChannel);
	}

	// std::vector<int> fromTo = { 0,0,1,1,2,2,3,3,4,4};
	// cv:: (first, firstChannel, fromTo);

	cv::Mat fusedImg;
	std::vector<cv::Mat> channelsFI = {firstChannel, secondChannel, thirdChannel};
	cv::merge(channelsFI, fusedImg);

	L.clear();
	lMu.clear();
	gMu.clear();
	return fusedImg;	
}

cv::Mat coordinator(cv::Mat Io, cv::Mat Ihaze) {
	
	float x_min = 0.15;
	cv::Mat I1, I2;

	cv::Mat Image;
	cv::Mat IhazeImg;

	Io.convertTo(Image, CV_8UC3, 255);
	Ihaze.convertTo(IhazeImg, CV_8UC3, 255);

	cv::cvtColor(Image, I1, cv::COLOR_BGR2HSV);
	cv::cvtColor(IhazeImg, I2, cv::COLOR_BGR2HSV);

	std::vector<cv::Mat> channels_I1;
	std::vector<cv::Mat> channels_I2;
	cv::split(I1, channels_I1);
	cv::split(I2, channels_I2);

	double a = cv::sum(channels_I1[2])[0];
	double b = cv::sum(channels_I1[1])[0];

	double c = cv::sum(channels_I2[2])[0];
	double d = cv::sum(channels_I2[1])[0];
	
	cv::Mat tempMat;

	cv::subtract(channels_I1[2], channels_I1[1], tempMat);
	cv::threshold(tempMat, tempMat, x_min, 1, cv::THRESH_TOZERO);
	double e = cv::sum(tempMat)[0];

	cv::subtract(channels_I2[2], channels_I2[1], tempMat);
	cv::threshold(tempMat, tempMat, x_min, 1, cv::THRESH_TOZERO);
	double f = cv::sum(tempMat)[0];

	double y = e / f;
	double x = (a - y*(c - d)) / b;

	if (x < 1) x = 1;

	channels_I1[1].convertTo(channels_I1[1], channels_I1[1].type(), x);

	cv::merge(channels_I1, I1);
	cv::cvtColor(I1, I1, cv::COLOR_HSV2BGR);

	return I1;
}

cv::Mat atif_mef_thermal(const cv::Mat I, float clip_range) {

	// 10 bit input

	cv::Mat I_hazy;
	double g = pow(2, 14);
	I.convertTo(I_hazy, CV_32F, (1.0 / (g - 1.0)));
	double min, max;
	cv::minMaxIdx(I_hazy, &min, &max);
	vector<cv::Mat> Images;

	//gamma correction
	float gamma[] = { 1.2, 2, 4, 8 };
	std::vector<cv::Mat> gammaCorrectedImgs = gamma_correction(I_hazy, gamma);
	Images.insert(Images.end(), gammaCorrectedImgs.begin(), gammaCorrectedImgs.end());

	//clahe
	cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE();
	clahe->setClipLimit(clip_range); //4

	cv::Mat claheIn, claheOut;
	I_hazy.convertTo(claheIn, CV_8U, 255.0);
	clahe->apply(claheIn, claheOut);

	claheOut.convertTo(claheOut, CV_32F, (1.0 / 255.0));
	Images.push_back(claheOut);

	int r = 12;
	cv::Mat R = fastExpoFuse_thermal(Images, r);
	return R;
	//return coordinator(R, I_hazy);
}

cv::Mat fastExpoFuse_thermal(std::vector<cv::Mat> Io, int r) {

	// [Hei, Wid, ~, N] = size(Io);
	int Hei = Io[0].rows;
	int Wid = Io[0].cols;
	int N = Io.size();

	//  < Parameters > 
	float alpha = 1.1;
	float gSig = 0.2;
	float lSig = 0.5;
	float SigD = 0.12;

	float epsil = 0.25;
	int np = Hei*Wid;

	cv::Mat H = cv::Mat::ones(cv::Size(7, 7), CV_32F);
	H = H / (49);

	// cv::Mat L1 = cv::Mat::ones(cv::Size(Wid, Hei), CV_32FC(6)); // ?? daha h�zl� m� olur ? 

	std::vector<cv::Mat> L;
	std::vector<cv::Mat> gMu;
	std::vector<cv::Mat> lMu;
	cv::Mat Iones = cv::Mat::ones(cv::Size(Wid, Hei), CV_32F);

	for (int i = 0; i < N; i++)
	{
		cv::Mat Ig = Io[i].clone(); //
		cv::Mat IgPad = padImage(Ig, 3, 3);
		cv::Mat tempL = conv2(IgPad, H);
		L.push_back(tempL);

		double coeff = cv::sum(Ig)[0] / np;
		gMu.push_back(Iones * coeff);

		cv::Mat temp_lMu = fastGF(Ig, r, epsil, 2.5);
		lMu.push_back(temp_lMu);
	}

	float Sig2 = 2 * pow(SigD, 2);
	std::vector<cv::Mat> sMap;
	std::vector<cv::Mat> muMap;

	cv::Mat normalizerS = cv::Mat::zeros(cv::Size(Wid, Hei), CV_32FC1);
	cv::Mat normalizerMu = cv::Mat::zeros(cv::Size(Wid, Hei), CV_32FC1);

	for (int i = 0; i < N; i++)
	{
		sMap.push_back(cv::Mat::ones(cv::Size(Wid, Hei), CV_32FC1));
		cv::Mat t = (L[i] - 0.5);
		cv::pow(t, 2.0, t);
		t = t / Sig2;
		t = t *(-1);
		cv::exp(t, sMap[i]);
		sMap[i] = sMap[i] + 1e-6;
		cv::add(normalizerS, sMap[i], normalizerS);

		muMap.push_back(cv::Mat::ones(cv::Size(Wid, Hei), CV_32FC1));
		cv::Mat t2 = (gMu[i] - 0.5);
		cv::pow(t2, 2.0, t2);
		t2 = t2 / (pow(gSig, 2));
		cv::Mat t3 = (lMu[i] - 0.5);
		cv::pow(t3, 2.0, t3);
		t3 = t3 / (pow(lSig, 2));

		cv::add(t3, t2, t2);
		t2 = t2 * (-0.5);
		cv::exp(t2, muMap[i]);

		cv::add(normalizerMu, muMap[i], normalizerMu);
	}

	for (int h = 0; h < sMap.size(); h++) {
		cv::divide(sMap[h], normalizerS, sMap[h]);
		cv::divide(muMap[h], normalizerMu, muMap[h]);
	}


	std::vector<cv::Mat> Ist_b, Ist_g, Ist_r, channels;

	for (int n = 0; n < lMu.size(); n++)
	{
		cv::split(Io[n], channels);
		cv::Mat y;

		cv::subtract(channels[0], lMu[n], y);
		Ist_b.push_back(y.clone());

		channels.clear();
	}

	cv::Mat firstChannel = cv::Mat::zeros(cv::Size(Wid, Hei), CV_32F);


	for (int n = 0; n < lMu.size(); n++)
	{
		cv::Mat a, b, c;
		cv::multiply(muMap[n], lMu[n], b);

		cv::multiply(sMap[n], Ist_b[n], a, alpha);
		cv::add(a, b, c);
		cv::add(firstChannel, c.clone(), firstChannel);
	}

	// std::vector<int> fromTo = { 0,0,1,1,2,2,3,3,4,4};
	// cv:: (first, firstChannel, fromTo);

	cv::Mat fusedImg;
	std::vector<cv::Mat> channelsFI = { firstChannel };

	L.clear();
	lMu.clear();
	gMu.clear();
	return firstChannel;
}