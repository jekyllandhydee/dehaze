#pragma once

#include "opencv2/opencv.hpp"

cv::Mat AWB_MeanLuminance(const cv::Mat image);