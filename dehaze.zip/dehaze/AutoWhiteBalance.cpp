
#include "AutoWhiteBalance.h"

cv::Mat AWB_MeanLuminance(const cv::Mat image) {
	// CV_16UC3 input image; 16-bit
	image.convertTo(image, CV_16UC3, pow(2,6));

	std::vector<cv::Mat> channels_bgr;
	std::vector<cv::Mat> channels_ycrcb;

	cv::split(image, channels_bgr);
	cv::Mat ycrcb;
	cv::cvtColor(image, ycrcb, cv::COLOR_BGR2YCrCb);
	cv::split(ycrcb, channels_ycrcb);

	float Y_mean = cv::mean(channels_ycrcb[0])[0];
	float Ir_mean = cv::mean(channels_bgr[2])[0];
	float Ig_mean = cv::mean(channels_bgr[1])[0];
	float Ib_mean = cv::mean(channels_bgr[0])[0];
	channels_bgr[0] = channels_bgr[0] * (Y_mean / Ib_mean);
	channels_bgr[1] = channels_bgr[1] * (Y_mean / Ig_mean);
	channels_bgr[2] = channels_bgr[2] * (Y_mean / Ir_mean);

	cv::Mat img_awb;
	cv::merge(channels_bgr, img_awb); // 16-bit result
	return img_awb;
}