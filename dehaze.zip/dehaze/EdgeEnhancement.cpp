#include "EdgeEnhancement.h"

cv::Mat calcuate_hf(cv::Mat Image) {

	// takes 16-bit 3-channel input 
	cv::Mat I_hazy_ycrcb;
	cv::cvtColor(Image, I_hazy_ycrcb, cv::COLOR_BGR2YCrCb); // 16-bit
	std::vector<cv::Mat> channels_ycrcb;
	cv::split(I_hazy_ycrcb, channels_ycrcb);

	int gaussSigma = 4;
	cv::Mat filter = cv::getGaussianKernel(9, gaussSigma);
	filter = filter / cv::sum(filter)[0];
	cv::Mat im_base_gxy;
	cv::Mat filter_y;
	cv::transpose(filter, filter_y);
	cv::sepFilter2D(channels_ycrcb[0], im_base_gxy, channels_ycrcb[0].depth(), filter, filter_y);
	cv::Mat im_hf = channels_ycrcb[0] - im_base_gxy; // 16-bit im_hf (positive) (i.e. eliminating noise)

	// cv::threshold(im_hf, im_hf, 700, 0, cv::THRESH_TOZERO);
	return im_hf;
}

void enhanceEdges(cv::Mat hazy_image, cv::Mat &dehazed) {

	cv::Mat im_hf = calcuate_hf(hazy_image);

	//  CV_8UC3 input 
	dehazed.convertTo(dehazed, CV_16U, pow(2, 8));
	cv::Mat ycrcbDeh;
	cv::cvtColor(dehazed, ycrcbDeh, cv::COLOR_BGR2YCrCb);
	std::vector<cv::Mat> ycrcbChannelsDeh;
	cv::split(ycrcbDeh, ycrcbChannelsDeh);
	ycrcbChannelsDeh[0] += im_hf;
	cv::merge(ycrcbChannelsDeh, ycrcbDeh);
	cv::cvtColor(ycrcbDeh, dehazed, cv::COLOR_YCrCb2BGR); //  CV_16UC3 dehazed 			
}
