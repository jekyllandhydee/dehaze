#pragma once

#include "opencv2/opencv.hpp"

cv::Mat calcuate_hf(cv::Mat Image); // return im_hf 
void enhanceEdges(cv::Mat hazy_image, cv::Mat &dehazed);
